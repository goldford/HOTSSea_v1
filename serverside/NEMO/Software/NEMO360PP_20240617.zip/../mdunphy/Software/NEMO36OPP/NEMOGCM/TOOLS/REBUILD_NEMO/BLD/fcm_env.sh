#!/bin/sh
PATH=/home/mdunphy/Software/NEMO36OPP/NEMOGCM/TOOLS/REBUILD_NEMO/BLD/bin:$PATH
export PATH
