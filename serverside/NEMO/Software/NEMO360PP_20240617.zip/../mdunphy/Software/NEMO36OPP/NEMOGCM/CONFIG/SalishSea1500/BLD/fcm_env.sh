#!/bin/sh
PATH=/home/mdunphy/Software/NEMO36OPP/NEMOGCM/CONFIG/SalishSea1500/BLD/bin:$PATH
export PATH
