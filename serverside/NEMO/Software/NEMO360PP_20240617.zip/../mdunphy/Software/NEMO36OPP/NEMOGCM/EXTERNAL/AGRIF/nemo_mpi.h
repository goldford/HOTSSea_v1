#if defined key_mpp_mpi
#define AGRIF_MPI
#endif
