#!/bin/sh
PATH=/home/mdunphy/Software/NEMO36OPP/NEMOGCM/TOOLS/MPP_PREP/BLD/bin:$PATH
export PATH
