# NEMO36OPP - NEMO 3.6 OPP version

## Purpose

This repository aims to provide a converged code version for OPP Functional Area 1 & 2. Modifications are organized loosely following the approach used in the CONCEPTS code version. Here the modified source code files are stored in `NEMOGCM/CONFIG/SHARED/MY_SRC`, and the edits are activated with **key_opp**.  Configurations use the modified files by either:

1. Symlinking the `MY_SRC` directory:

        cd NEMOGCM/CONFIG/MyPort
        ln -s ../SHARED/MY_SRC MY_SRC

1. or symlinking each file in the `MY_SRC` directory:

        cd NEMOGCM/CONFIG/MyPort && mkdir -p MY_SRC && cd MY_SRC
        ln -s ../../SHARED/MY_SRC/*

The first choice is preferred as it maximizes simplicity and reduces code divergence. The second option is more amenable to further code development. Further code developments should get merged into `SHARED/MY_SRC` under an appropriate key.


## Code version details

The repository is initialized with NEMO 3.6 rev10584 from upstream as to be up-to-date in terms of bugfixes. Improvements from UBC, Dal and DFO colleagues are included under new keys as follows:

1. **key_opp**  

    1. Sea-surface height boundary condition for barotropic velocities.
       Activate with `cn_dyn2d='ssh'` in `nambdy` and provide `ssh` in the OBC file.  
       Credit: Youyu Lu

    1. U, V and SSH initial conditions from data.  
       Credit: Christoph Renkl

    1. Sponge and Orlanski-with-sponge boundary conditions for baroclinic velocities.
       Activate with `cn_dyn3d='sponge'` or `cn_dyn3d='orlanski_w_sponge'` in `nambdy`.
       Also requires new namelist parameter `rn_max_sponge` (default value 20 in `namelist_ref`).  
       Credit: Susan Allen

    1. Static SSH offset for open boundary condition.
       Requires a new parameter `rn_ssh_offset` in namelist `nambdy` (default is zero in `namelist_ref`).  
       Credit: Susan Allen

    1. Vertical advection sub-time stepping ratio moved to namelist parameters
       `nn_traadv_tvd_zts` for tracers and `nn_dynzad_zts` for dynamics.
       Default value is 5 for both in `namelist_ref` which matches the original hardcoded value.  
       Credit: Michael Dunphy

    The new namelist parameters are added to `SHARED/namelist_ref`.

1. **key_cliptemp**  
    Ensures that temperature does not drop below -2C. Used to keep NEMO stable without an ice model.  
    Credit: Li Zhai

1. **key_botpreonly**   
    Limits dia_ar5 to compute only bottom pressure.  
    Credit: Xianmin Hu

1. **key_salishsea**  
    Edits specific for the Salish Sea configuration:

    1. Split bottom friction into u and v components
    1. Apply tmask to e1t, e2t in ldfdyn_c2d and ldfdyn_c3d  
    
    Credit: Susan Allen and Michael Dunphy

1. **key_turbo**  
    Optimization for the vertical advection sub-timestepping for tracers and momentum, achieves a modest speedup (5-10%). Keyed because it is experimental.
    
    Credit: Michael Dunphy


### Non-keyed changes

A few edits are included without wrapping in a key:

1. Fix for correct U,V point generation in the `agrif_create_coordinates` tool
1. A bunch of initializations for uninitialized variables
1. A few trivial log writing adjustments
1. Fix for namelist reading nambdy_tide (NEMO bug #2294)
1. Increase simulation failure detection limit from 10 m to 15 m for ssh


### Arch files

1. **`arch-GCC_UBUNTU1604.fcm`**:
    For Ubuntu 16.04 and GCC compiler (such as linux desktop).

1. **`arch-GPSC-GCC.fcm`**:
    For GPSC Ubuntu 18.04 and GCC compiler.

1. **`arch-GPSC-INTEL2019.fcm`**:
    For GPSC Ubuntu 18.04 and Intel 2019 compiler. When using this ARCH file, you also need a hand-compiled HDF5NETCDF and XIOS-2.5 in `$HOME/NEMO` (we have been doing this for months).

1. **`arch-GPSC-INTEL2019-STATIC.fcm`**:
    For GPSC Ubuntu 18.04, Intel 2019 compiler, and ECCC's SSM packages for NetCDF and XIOS. This one does not require any hand-compiled NetCDF or XIOS. The specific SSM packages you need are:

        # Intel 2019 plus OpenMPI plus OpenMPI-setup
        . ssmuse-sh -x comm/eccc/all/opt/intelcomp/intelpsxe-cluster-19.0.3.199
        . ssmuse-sh -x main/opt/openmpi/openmpi-3.1.2--hpcx-2.4.0-mofed-4.6--intel-19.0.3.199
        . ssmuse-sh -x main/opt/openmpi-setup/openmpi-setup-0.2

        # ECCC's parallel static netcdf4 and XIOS-2
        . ssmuse-sh -x hpco/exp/hdf5-netcdf4/parallel/openmpi-3.1.2/static/intel-19.0.3.199/01
        . ssmuse-sh -x eccc/mrd/rpn/OCEAN/xios-par-2.0.1627.1
    Note that the openmpi-setup package sets a bunch of openmpi environment variables that we were setting by hand before. It is preferable to use the openmpi-setup package here because then you always get the latest-greatest environment variables as configured for gpsc4 by SSC.
